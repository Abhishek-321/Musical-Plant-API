/*
This example uses Johnny-five, it is meant to be opened with a web browser the user has 3 buttons to chose from. 
GREEN   GOOD    
YELLOW  DRY
RED     WET

CALATHEA PLANT HUMIDITY NUMBERS
Calathea's optimal watering was: 
DRY:  760 - 959           => IN THE CODE => Yellow
OPTIMAL: 960 - 1015       => IN THE CODE => Green
WET: 1001 - 1160          => IN THE CODE => Red

PS: It's called Raw because I'm losing my mind.

****ARDUINO BUILD: ****
Arduino is connected to 
3 LED lights (Red, Yellow & Green)
1 Peizo speaker (set to port 12, used in this case with built in tone arduino code)
4  220ohm resistances connected to Speaker & LEDS
GreenledPin = 9
YellowledPin = 10
RedledPin = 11
Peizo = 12

SET ARDUINO TO READ FIRMATA 
****

* HERE * 
Open new terminal: 
cd Raw
node app.js
GO TO: 
http://localhost:3001/
cry tears of joy that J5 is working.
*/
// Initiates Johnny-five
const five = require("johnny-five");
// { Board, Led, }
const board = new five.Board({ port: "COM3"}); //CHANGE THIS

//Initiates Express
const express = require("express");
const app = express();

board.on("ready", () => {
//creates a variable for the led connected to the port - in this case port 9
    const greenLed = new five.Led(9); 
    const redLed = new five.Led(11); 
    const yellowLed = new five.Led(10); 
    
    var piezo = new five.Piezo(12);

    // Injects the piezo into the repl
    board.repl.inject({
      piezo: piezo
    });
  
    //initiates server on port 3001
    app.listen(3001, () => { console.log("listening at 3001") });
    app.use(express.static("public"));
    app.use(express.json({ limit: "1mb" }));

    app.post("/set-arduino-light", (request, response) => {
        const data = request.body;

        greenLed.stop().off();
        redLed.stop().off();
        yellowLed.stop().off();

        //for debugging
        console.log("message: " + data.message);
    
    
        if (data.message == "Green") {
            greenLed.fadeIn();
         

            // Plays a song
        piezo.play({
            song: [
          
             //   ["G4", 1], //wet
             //["D4", 1], //dry
            ["B4", 1 ], //good
            [null, 1 / 4]
              ],
              tempo: 100
            });
        }
        else if (data.message == "Red") {
            redLed.fadeIn();
            piezo.play({
                song: [
              
            ["G4", 1], //wet  
            [null, 1 / 4]
                  ],
                  tempo: 100
                });
        }
        else if (data.message == "Yellow") {
            yellowLed.fadeIn();
            piezo.play({
                song: [
             ["D4", 1], //dry
             [null, 1 / 4]
                  ],
                  tempo: 100
                });
        } 
        
        response.json({
        status: "success",
        data: JSON.stringify(data)
        });
    });
   
});