
This example uses Johnny-five, Arduino example: Standard Firmata Plus, and Tone.js 
The point of this prototype:
The humidity sensor broke, so, I improvised with the data I had and LED's to represent the data. See data below*
This will help us test from a distance, (users will not see lights, or colors) and ask users, 
with a plant in front of them if they understand which sound means what. 

**ARDUINO BUILD:**
Arduino is connected to 
3 LED lights (Red, Yellow & Green)
1 Peizo speaker (set to port 12, used in this case with built in tone arduino code)
4  220ohm resistances connected to Speaker & LEDS

**What goes where?**
GreenledPin = 9
YellowledPin = 10
RedledPin = 11
Peizo = 12

Connect +positive LED pins to 220 ohm resistors (yes, one per LED, trust me.)
Connect pins 9 - 11 to LED +positive pin (longest pin) 
Connect pin 12 to +positive peizo pin
Connect ~GND to -Negative side of breadboard .
Connect all LED -negative pin (short pin) to ~GND
Connect GND to other -negative side of breadboard 
Connect resistor to -negative to -negative peizo pin. 

SET ARDUINO TO READ *STANDARD FIRMATA PLUS* 
****

**HERE**
Open new terminal: 
Navigate to the terminal and type cd Raw 
npm install
node app.js to run the server
GO TO: 
http://localhost:3001/
cry tears of joy that everything is working.


**HUMIDITY DATA**
GREEN   GOOD    
YELLOW  DRY
RED     WET

CALATHEA PLANT HUMIDITY NUMBERS
Calathea's optimal watering was: 
DRY:  760 - 959           => IN THE CODE => Yellow
OPTIMAL: 960 - 1015       => IN THE CODE => Green
WET: 1001 - 1160          => IN THE CODE => Red

These numbers will have to be adjusted for any plant.
In theory, our design is to encourage users to water their plants
a somewhat training practice for them with Calathea.
Calathea plants are the hardest to kill. 
The only reason they die is because they're not getting enough water.
Our users are primarily bad waterers. Overwatering & Underwatering bad plant habits. 


**Future?**
This build allows for Ahbi & Freddie's code to be integrated with their sound explorations. 
Furthermore, Tone.js can use MP3 music, I just haven't managed to get it working with local files 
but had success with webhosted mp3's. 

In the future it would be nessesary to create a feature that "resets" 
the numbers to be automatic and adjusts accordingly in real time.
Example: 
Instructions: 
Water Calathea with 250 ml (cup provided)
The user hits a reset button indicating the plant has been watered.
The code should be able to adapt itself.
The differences between stupid wet, good, and dry were on average 200, 
but these numbers deserve to be explored longterm to get better numbers for the proximity "Touch"

PS: It's called Raw because I'm losing my mind.

ᚳ ᛞ ᚱ